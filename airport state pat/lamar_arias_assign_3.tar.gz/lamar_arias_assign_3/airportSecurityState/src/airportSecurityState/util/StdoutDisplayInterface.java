package airportSecurityState.util;
public interface StdoutDisplayInterface{

	public void writeToStdout(String o);
}
