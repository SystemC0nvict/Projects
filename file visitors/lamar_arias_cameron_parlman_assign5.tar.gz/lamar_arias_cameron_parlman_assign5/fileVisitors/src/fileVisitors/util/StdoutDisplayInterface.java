package fileVisitors.util;
public interface StdoutDisplayInterface{

	public void writeToStdout(String o);
	public void writeToScreen(String o);
	public void writeToScreen();
}
