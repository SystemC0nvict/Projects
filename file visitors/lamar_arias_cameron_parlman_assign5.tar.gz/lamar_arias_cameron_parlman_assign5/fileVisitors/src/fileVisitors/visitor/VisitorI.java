package fileVisitors.visitor;
import fileVisitors.visitor.Treebuilder;
public interface VisitorI {

	public void visit(Treebuilder tree);

}
