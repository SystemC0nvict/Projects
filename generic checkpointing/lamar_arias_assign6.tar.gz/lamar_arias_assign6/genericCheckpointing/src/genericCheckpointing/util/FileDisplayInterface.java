package genericCheckpointing.util;
import java.util.ArrayList;
public interface FileDisplayInterface{

	void writeToFile(String out);
	public void writeSchedulesToFile(String banana);
	
}
